<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use App\Models\User;

class AuthLoginController extends Controller
{

    public function login(Request $request){
        try{
            $ip=\Request::ip();
            $useragents=\Request::userAgent();
        
            // return response()->json([
            //     'status'=>500,
            //     'ip'=>$ip,
            //     'message'=>$useragents,
            // ]);

            $login = $request->input('email');
            $type = filter_var($login , FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
            

            $validator='';
            if($type=='email'){
                $validator=Validator::make($request->all(),[
                    'email'=>'required|email',
                    'password'=>'required|min:8',
                ]);
            }
            else{
                $validator=Validator::make($request->all(),[
                    'email'=>'required|string',
                    'password'=>'required|min:8',
                ]);
            }


            if($validator->fails()){
                return response()->json([
                    'errors'=>$validator->messages(),
                ]);
            }
            else{
                if($type=='email'){
                    $user=User::Where('email',$request->email)->first();
                }
                else{
                    $user=User::Where('username',$request->email)->first();
                }

                if(!$user || ! Hash::check($request->password,$user->password)){
                    return response()->json([
                        'status'=>401,
                        'message'=>'These credentials do not match our records.',
                    ]);
                }
                else{
                    $token= $user->createToken($user->email.'_Token')->plainTextToken;
                    return response()->json([
                        'status'=>200,
                        'username'=>$user->Username,
                        'token'=>$token,
                        'message'=>'Logged in',
                    ]);
                }

            }
        } 
        catch(\Illuminate\Database\QueryException $ex){ 

            $errors=$ex->getMessage();
            // 2002
            $beingusederror='No connection could be made because the target machine actively refused it';

            $error=$ex->getMessage();
            if (preg_match("/$beingusederror/i", $errors)) {
                $error="Connection has been Lost. Please Contact Support\n";
            }

            return response()->json([
                'status'=>500,
                'message'=>$error,
            ]);
        }

    }

    public function logout(){
            auth()->user()->tokens()->delete();
            return response()->json([
                'status'=>200,
                'message'=>'Logged out',
            ]);
    }
}
