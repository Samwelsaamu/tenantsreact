<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Property;

use App\Models\UserLogs;
use App\Models\Message;
use App\Model\WaterMessage;

class MiscController extends Controller
{
    //
    public function smsDeliveryReports(Request $request){
        
        $id=$request->input('id');
        $status=$request->input('status');
        $phoneNumber =$request->input('phoneNumber');
        $networkCode =$request->input('networkCode');
        $failureReason= $request->input('failureReason');
        $retryCount =$request->input('retryCount');

        $update=Message::where('MessageId',$id)
                ->update(['Status'=>$status]);

        $updatewatermessage=WaterMessage::where('MessageId',$id)
                ->update(['Status'=>$status]);

        Property::setLogs("Found:".$id." ".$status." ".$phoneNumber." ".$failureReason);
       
    }
}
