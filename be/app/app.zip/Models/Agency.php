<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Agency;

class Agency extends Model
{
	
    use HasFactory;

    protected $fillable=[
	    'Names',
		'Address',
		'Town',
		'Phone',
		'Email',
	];

	public static function getAgencyName(){
        try { 
            $results = Agency::all();
            $resultname='';
                foreach($results as $result){
                   $resultname= $result['Names'];
                }
            return $resultname;
        } catch(\Illuminate\Database\QueryException $ex){ 
            return 'Oops.Internal Server Error.';
        }
        
    }

    public static function getAgencyEmail(){
        try { 
            $results = Agency::all();
            $resultname='';
                foreach($results as $result){
                   $resultname= $result['Email'];
                }
            return $resultname;
        } catch(\Illuminate\Database\QueryException $ex){ 
            return 'Oops.Internal Server Error.';
        }
    }

    public static function getAgencyPhone(){
        try { 
            $results = Agency::all();
            $resultname='';
                foreach($results as $result){
                   $resultname= $result['Phone'];
                }
            return $resultname;
        } catch(\Illuminate\Database\QueryException $ex){ 
            return 'Oops.Internal Server Error.';
        }
    }

    public static function getAgencyTown(){
        try { 
            $results = Agency::all();
            $resultname='';
                foreach($results as $result){
                   $resultname= $result['Town'];
                }
            return $resultname;
        } catch(\Illuminate\Database\QueryException $ex){ 
            return 'Oops.Internal Server Error.';
        }
    }

    public static function getAgencyAddress(){
        try { 
            $results = Agency::all();
            $resultname='';
                foreach($results as $result){
                   $resultname= $result['Address'];
                }
            return $resultname;
        } catch(\Illuminate\Database\QueryException $ex){ 
            return 'Oops.Internal Server Error.';
        }
    }

    public static function getAfricasKey(){
        // return $apiKey     = "3615e3899a823bbad9bb58766e99098864a3638189c3a087a79b04c7e332ade3";//live
        return $apiKey     = "atsk_e2ea0753a6d9a577aa8015915062205f3d9d32f2bbc07f3205dc8dae99195f8b82def8ba";//sandbox
    }

    public static function getAfricasUsername(){
        // return $username   = "WAGITONGA";//live
        return $username   = "sandbox";//sandbox
    }

    public static function getAfricasFrom(){
        // return $username   = "WAGITONGA";//live
        return $from   = "28025";//sandbox
    }
}
