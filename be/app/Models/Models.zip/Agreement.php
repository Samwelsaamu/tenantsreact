<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Agreement extends Model
{
    use HasFactory;

    protected $fillable=[
    	'Plot',
		'House',
		'Tenant',
		'DateAssigned',
		'DateTo',
		'DateVacated',
		'Month',
		'Deposit',
		'Arrears',
		'Damages',
		'Transaction',
		'Refund',
		'Phone',
		'UniqueID',
    ];
}
