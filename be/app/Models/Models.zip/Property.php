<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use App\Models\Property;
use App\Models\House;
use App\Models\UserLogs;
use App\Models\User;
use App\Models\Report;
use Illuminate\Support\Facades\Auth;

class Property extends Model
{
    use HasFactory;

    protected $fillable=[
    	'Plotname',
		'Plotarea',
		'Plotcode',
		'Plotaddr',
		'Plotdesc',
		'Waterbill',
		'Deposit',
		'Waterdeposit',
		'Outsourced',
		'Garbage',
		'Kplcdeposit',
    ];

    public static function getUsername($id){
        $results = User::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['email'];
            }
        return $resultname;
    }

    public static function getProfilename($id){
        $results = User::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Fullname'];
            }
        return $resultname;
    }

    // public static function getHousePropertyID($id){
    //     $results = House::where('id',$id)->get();
    //     $resultname='';
    //         foreach($results as $result){
    //            $resultname= $result['Plot'];
    //         }
    //     return $resultname;
    // }

    public static function getPropertyName($id){
        $results = Property::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Plotname'];
            }
        return $resultname;
    }

    public static function getPropertyCode($id){
        $results = Property::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Plotcode'];
            }
        return $resultname;
    }

    public static function getHouseProperty($id){
        $results = House::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Plot'];
            }
        return $resultname;
    }
    public static function getHouseName($id){
        $results = House::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Housename'];
            }
        return $resultname;
    }

    public static function getHouseCode($housename){
        $results = House::where('Housename',$housename)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['id'];
            }
        return $resultname;
    }

    public static function tenantStatus($id){
       $results = Tenant::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Status'];
            }
        return $resultname;
    }

    public static function getMonthDateAddWater($yearmonth){
        $explomonth=explode(' ', $yearmonth);
        $years=$explomonth[0];
        $months=$explomonth[1];
        $yearmonthday=$years.'-'.$months.'-1';
        $month=date_format(date_create($yearmonthday),'Y, M');
        return $month;
    }

    public static function getMonthDateDash($yearmonth){
        $explomonth=explode(' ', $yearmonth);
        $years=$explomonth[0];
        $months=$explomonth[1];
        $yearmonthday=$years.'-'.$months.'-1';
        $month=date_format(date_create($yearmonthday),'M');
        return $month;
    }
    public static function getYearDateDash($yearmonth){
        $explomonth=explode(' ', $yearmonth);
        $years=$explomonth[0];
        $months=$explomonth[1];
        $yearmonthday=$years.'-'.$months.'-1';
        $month=date_format(date_create($yearmonthday),'Y');
        return $month;
    }

    public static function PatchNo(){
        $nextpatch=DB::table('payment_messages')->max('PatchNo');
        if($nextpatch){
            return $nextpatch++;
        }
        else{
            return 1;
        }
    }

    public static function checkCurrentTenant($hid){
        $currentlyassigned=DB::table('agreements')->where([
            'House'=>$hid,
            'Month'=>0
        ])->max('Tenant');
        return $currentlyassigned;
    }
    public static function checkCurrentTenantHouse($tid){
        $currentlyassigned=DB::table('agreements')->where([
            'Tenant'=>$tid,
            'Month'=>0
        ])->max('House');
        return $currentlyassigned;
    }
    public static function checkCurrentTenantName($id){
        $results = Tenant::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Fname'].' '.$result['Oname'];
            }
        return $resultname;
    }
    public static function checkCurrentTenantNamePayment($id){
        $results = Tenant::where('id',$id)->get();
        $resultname='Vacant';
            foreach($results as $result){
               $resultname= $result['Fname'].' '.$result['Oname'];
            }
        return $resultname;
    }
    public static function checkCurrentTenantBill($hid,$tenant,$month){
        $waters=DB::table('waters')->where([
            'Tenant'=>$tenant,
            'House'=>$hid,
            'Month'=>$month
        ])->max('id');
        return $waters;
    }

    public static function checkCurrentTenantPreviousBill($hid,$tenant,$month){
        $waters=DB::table('waters')->where([
            'Tenant'=>$tenant,
            'House'=>$hid,
            'Month'=>$month
        ])->max('Previous');
        return $waters;
    }

    public static function checkCurrentTenantCurrentBill($hid,$tenant,$month){
        $waters=DB::table('waters')->where([
            'Tenant'=>$tenant,
            'House'=>$hid,
            'Month'=>$month
        ])->max('Current');
        return $waters;
    }

    public static function setUserLogs($message){
        $id=Auth::user()->id;
        $savelog = new UserLogs;
        $savelog->User =$id;
        $savelog->Message =$message;
        $savelog->save();
    }

    public static function setLogs($message){
        $savelog = new UserLogs;
        $savelog->User ='System';
        $savelog->Message =$message;
        $savelog->save();
    }

    public static function PaymentKPLC($id,$hid,$month){
        $KPLC=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('KPLC');
        return $KPLC;
    }

    public static function PaymentWater($id,$hid,$month){
        $Water=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Water');
        return $Water;
    }

    public static function PaymentId($id,$hid,$month){
        $pid=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->max('id');
        return $pid;
    }

    public static function PaymentExcess($id,$hid,$month){
        $Excess=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Excess');
        return $Excess;
    }

    public static function PaymentArrears($id,$hid,$month){
        $Arrears=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Arrears');
        return $Arrears;
    }

    public static function PaymentRent($id,$hid,$month){
        $Rent=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Rent');
        return $Rent;
    }

    public static function PaymentGarbage($id,$hid,$month){
        $Garbage=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Garbage');
        return $Garbage;
    }

    public static function PaymentWaterbill($id,$hid,$month){
        $Waterbill=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Waterbill');
        return $Waterbill;
    }
    public static function PaymentHseDeposit($id,$hid,$month){
        $HseDeposit=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('HseDeposit');
        return $HseDeposit;
    }

    public static function PaymentDeposit($id,$hid,$month){
        $KPLC=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('KPLC');

        $HseDeposit=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('HseDeposit');

        $Water=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Water');

        $Deposit=$KPLC+$HseDeposit+$Water;
        return $Deposit;
    }

    public static function PaymentLease($id,$hid,$month){
        $Lease=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Lease');
        return $Lease;
    }

     public static function PaymentTotals($id,$hid,$month){
        $Arrears=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Arrears');

        $Excess=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Excess');

        $Rent=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Rent');

        $Garbage=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Garbage');

        $KPLC=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('KPLC');

        $HseDeposit=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('HseDeposit');

        $Water=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Water');

        $Lease=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Lease');

        $Waterbill=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Waterbill');

        $TotalUsed=$Rent+$Water+$Garbage+$Lease+$HseDeposit+$KPLC+$Waterbill+$Arrears;
        return $TotalUsed;
    }
    
    public static function PaymentPaid($id,$hid,$month){
        $Excess=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Excess');

        $Equity=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Equity');

        $Cooperative=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Cooperative');

        $Others=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Others');

        $PaidUploaded=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('PaidUploaded');
        $TotalPaid=$Excess+$Equity+$Cooperative+$Others+$PaidUploaded;
        return $TotalPaid;
    }

    public static function PaymentBal($id,$hid,$month){
        $Arrears=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Arrears');

        $Excess=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Excess');

        $Rent=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Rent');

        $Garbage=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Garbage');

        $KPLC=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('KPLC');

        $HseDeposit=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('HseDeposit');

        $Water=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Water');

        $Lease=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Lease');

        $Waterbill=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Waterbill');

        $Equity=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Equity');

        $Cooperative=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Cooperative');

        $Others=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('Others');

        $PaidUploaded=DB::table('payments')->where([
            'Tenant'=>$id,
            'House'=>$hid,
            'Month'=>$month
        ])->sum('PaidUploaded');
        $TotalUsed=$Rent+$Water+$Garbage+$Lease+$HseDeposit+$KPLC+$Waterbill+$Arrears;
        $TotalPaid=$Excess+$Equity+$Cooperative+$Others+$PaidUploaded;
        $Balance=$TotalUsed-$TotalPaid;
        return $Balance;
    }
    public static function getLastMonth($month,$monthdate){
        $watermonthlast= date("Y n",strtotime("-1 months",strtotime($monthdate)));
        return $watermonthlast;
    }

    public static function getLastMonthdate($watermonth){
        $explomonth=explode(' ', $watermonth);
        $years=$explomonth[0];
        $months=$explomonth[1];
        $yearmonthday=$years.'-'.$months.'-1';
        $month=date_format(date_create($yearmonthday),'Y-m-01');
        return $month;
    }
    public static function getPaymentUpdateId($id,$month){
        $Payments=DB::table('payments')->where([
            'House'=>$id,
            'Month'=>$month
        ])->max('id');
        return $Payments;
    }

    public static function getOnlineStatus($id){
        if (Auth::check()) {
            return $id==Auth::user()->id;
        }
    }

    public static function getCountHousesForProperty($id){
        $houses=DB::table('houses')->where([
            'Plot'=>$id
        ])->count();
        return $houses;
    }

    public static function getCountTenantsForHouses($id){
        $houses=DB::table('agreements')->where([
            'House'=>$id
        ])->count();
        return $houses;
    }

    public static function getMailIDSaved($uid){
        $mails=DB::table('mails')->where([
            'mailid'=>$uid
        ])->count();
        return $mails;
    }

    public static function saveReport($type,$fileName,$tid){
        $savereport = new Report;
        $savereport->DateTrans =date('Y-m-d');
        $savereport->Filename =$fileName;
        $savereport->Type =$type;
        $savereport->ReportTo =$tid;
        $savereport->save();
    }

    public static function dateToMonthName($yearmonth){
        $explomonth=explode(' ', $yearmonth);
        $years=$explomonth[0];
        $months=$explomonth[1];
        $yearmonthday=$years.'-'.$months.'-1';
        $month=date_format(date_create($yearmonthday),'Y_M');
        return $month;
    }

    public static function TenantNames($id){
        $results = Tenant::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Fname'].' '.$result['Oname'];
            }
        return $resultname;
    }

    public static function TenantFNames($id){
        $results = Tenant::where('id',$id)->get();
        $resultname='';
            foreach($results as $result){
               $resultname= $result['Fname'];
            }
        return $resultname;
    }
}
