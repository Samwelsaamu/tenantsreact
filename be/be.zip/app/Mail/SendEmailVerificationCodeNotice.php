<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendEmailVerificationCodeNotice extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $url;
    public $code;
    public $fullname;

    public function __construct($url,$code,$fullname)
    {
        $this->url = $url;
        $this->code = $code;
        $this->fullname = $fullname;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('emails.sendemailverificationcodenotice')
            ->with(['url' => $this->url,'code' => $this->code,'fullname' => $this->fullname])
            ->subject('Verification Code');
    }
}
