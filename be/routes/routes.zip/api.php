<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthLoginController;

use App\Http\Controllers\API\AdminController;

use App\Http\Controllers\API\MailController;
use App\Http\Controllers\MiscController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login',[AuthLoginController::class,'login']);

Route::group(['middleware' => 'auth:sanctum'], function (){
    Route::get('isAuthencticated',function (){
        return response()->json(['message'=>'Yes','status'=>200],200);
    });
    

    Route::get('update/waterbill/load',[AdminController::class,'setWaterbillPageInitial']);
    Route::get('update/waterbill/load/{id}/{month}',[AdminController::class,'setWaterbillPage']);
    Route::post('update/waterbill/preview',[AdminController::class,'previewWaterbill']);

    Route::get('update/rent/load/{id}/{month}',[AdminController::class,'setRentPage']);
    
    Route::get('update/monthlybills/load/{id}/{month}',[AdminController::class,'setMonthlyBillsPage']);
    Route::get('update/newtenant/monthlybills/load/{id}/{month}',[AdminController::class,'setNewTenantBillsPage']);
    Route::get('update/newtenant/monthlybills/load/{month}',[AdminController::class,'setNewTenantBillsPageInitial']);
    
    
    Route::post('save/waterbill/save',[AdminController::class,'savewaterbillnew']);
    Route::post('save/waterbill/upload',[AdminController::class,'saveupdatewaterbillupload']);
    Route::post('update/waterbill/save',[AdminController::class,'updatewaterbill']);

    Route::post('save/rentgarbage/save',[AdminController::class,'saveRentGarbagenew']);
    Route::post('save/rentgarbage/upload',[AdminController::class,'saveupdateRentGarbageupload']);
    Route::post('update/rentgarbage/save',[AdminController::class,'updateRentGarbage']);
    Route::post('generate/rentgarbage/selected',[AdminController::class,'generateRentGarbageSelected']);
    Route::post('generate/rentgarbage/all',[AdminController::class,'generateRentGarbageAll']);


    
    Route::post('save/monthlybills/save',[AdminController::class,'saveMonthlyBillnew']);
    


    Route::get('/properties/manage/load',[AdminController::class,'setManageProperty']);
    Route::get('/properties/manage/load/{id}',[AdminController::class,'manageProperty']);

    Route::get('/properties/mgr/tenants/load',[AdminController::class,'setManageTenant']);
    Route::get('/properties/mgr/tenants/load/{id}',[AdminController::class,'manageTenantIN']);

    Route::get('/properties/mgr/tenants/category/load',[AdminController::class,'setManageTenantCategory']);
    Route::get('/properties/mgr/tenants/category/load/{id}',[AdminController::class,'manageTenantINCategory']);

    Route::get('/properties/mgr/tenants/vacate/{hid}/{id}',[AdminController::class,'manageVacateTenant']);

    Route::get('/properties/mgr/tenants/assign/{hid}/{id}',[AdminController::class,'manageAssignTenant']);
    Route::get('/properties/mgr/tenants/addhouse/{hid}/{id}',[AdminController::class,'manageAddHouseTenant']);
    
    Route::get('/properties/mgr/tenants/reassign/{hid}/{id}/{shid}',[AdminController::class,'manageReassignTenant']);


    Route::get('/properties/house/{plot}/{id}',[AdminController::class,'manageHouseTenants']);

    
    Route::post('save/property/save',[AdminController::class,'saveProperty']);
    Route::post('update/property/save',[AdminController::class,'updateProperty']);
    Route::post('delete/property/save',[AdminController::class,'deleteProperty']);

    Route::post('save/house/save',[AdminController::class,'saveHouse']);
    Route::post('update/house/save',[AdminController::class,'updateHouse']);
    Route::post('delete/house/save',[AdminController::class,'deleteHouse']);

    
    Route::post('save/tenant/save',[AdminController::class,'saveTenant']);
    Route::post('update/tenant/save',[AdminController::class,'updateTenant']);
    Route::post('delete/tenant/save',[AdminController::class,'deleteTenant']);

    Route::post('vacate/house/save',[AdminController::class,'vacateHouse']);
    Route::post('assign/house/save',[AdminController::class,'assignHouse']);
    Route::post('addhouse/house/save',[AdminController::class,'addTenantHouse']);
    Route::post('reassign/house/save',[AdminController::class,'reassignHouse']);

    Route::post('send/message/new',[AdminController::class,'sendNewMessage']);

    Route::post('send/message/single/water',[AdminController::class,'sendSingleWaterMessage']);
    Route::post('send/message/all/water',[AdminController::class,'sendAllWaterMessage']);

   
    Route::post('send/message/tenant',[AdminController::class,'sendTenantMessage']);
    Route::post('send/message/all/tenant',[AdminController::class,'sendAllTenantMessage']);

    Route::post('send/message/reminder',[AdminController::class,'sendReminderMessage']);
    Route::post('send/message/all/reminder',[AdminController::class,'sendAllReminderMessage']);
    
    
    Route::post('delete/message/new/save',[AdminController::class,'deleteNewMessage']);

    

    Route::get('dash/month/prev/{month}',[AdminController::class,'getPreviousMonths']);
    Route::get('dash/water/{id}',[AdminController::class,'getWaterbill']);
    Route::get('dash/payments/{id}',[AdminController::class,'getPayments']);
    Route::get('dash/{id}',[AdminController::class,'getDashStats']);
    Route::get('dash/stats/{type}/{id}',[AdminController::class,'getDashboardStats']);
    Route::get('dash/insights/{month}',[AdminController::class,'getDashboardInsights']);
    
    Route::get('dash/insights/rents/{month}',[AdminController::class,'getDashboardInsightsRents']);

    Route::get('dash/tests/{type}/{id}',[AdminController::class,'Testing']);
    Route::get('dash/testing/{type}/{text}',[AdminController::class,'TestingSingle']);
    

    Route::get('update/messages/new/load',[AdminController::class, 'getComposedMessages']);
    
    Route::get('update/messages/water/load/{id}/{month}',[AdminController::class, 'setWaterbillPageMessages']);

    Route::get('update/messages/tenant/load/{id}',[AdminController::class, 'setTenantPageMessages']);
    Route::get('update/messages/payment/load/{id}/{month}',[AdminController::class, 'setPaymentPageMessages']);
    Route::get('update/messages/reminder/load/{id}/{month}',[AdminController::class, 'setReminderPageMessages']);
    

    Route::get('/getappdata',[AdminController::class, 'getappdata']);
    Route::get('search/load/{search}',[AdminController::class,'getSearchResult']);

    
    Route::post('logout',[AuthLoginController::class,'logout']);

    // SELECT Fname,Oname,Status FROM tenants WHERE Status IN('Assigned','Reassigned','Transferred');

    // SELECT tenants.Fname,tenants.Oname,tenants.Status,agreements.Month
    //  FROM tenants,agreements WHERE tenants.id=agreements.Tenant && tenants.Status IN('Assigned','Reassigned','Transferred') && agreements.Month=0; 


//     SELECT
//     tenants.Fname,
//     tenants.Oname,
//     tenants.Status,
//     agreements.Month,
//     COUNT(agreements.Tenant)
// FROM
//     tenants,
//     agreements
// WHERE
//     tenants.id = agreements.Tenant && agreements.Month = 0
// GROUP BY agreements.Tenant
// ORDER BY agreements.id
// ;

//doubles view
// SELECT
//     tenants.Fname,
//     tenants.Oname,
//     tenants.Status,
//     agreements.Month,
//     COUNT(agreements.Tenant) AS Doubles
// FROM
//     tenants,
//     agreements
// WHERE
//     tenants.id = agreements.Tenant && agreements.Month = 0
// GROUP BY
//     agreements.Tenant
// HAVING 
// 	Doubles >1
// ORDER BY
//     agreements.id;
    
// INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (NULL, '2021_01_22_144518_create_user_logs_table', '9');

// SELECT
//     id,Housename,Plot
// FROM
//    houses
// WHERE
//     Status='Occupied'
// ORDER BY
//     id DESC;



});

Route::post('/mesages/smsdelivery',[MiscController::class, 'smsDeliveryReports']);

Route::get('/properties/download/Reports/Waterbill/{id}/{month}',[MailController::class, 'downloadwaterbillexcel']);
// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });



// sandbox api key
// atsk_e2ea0753a6d9a577aa8015915062205f3d9d32f2bbc07f3205dc8dae99195f8b82def8ba

// {"status":"success","data":{"SMSMessageData":{"Message":"Sent to 2\/2 Total Cost: KES 4.8000 Message parts: 3","Recipients":[{"cost":"KES 2.4000","messageId":"ATXid_a095fe36f792e03fa063fd6816f9064f","number":"+254102782731","status":"Success","statusCode":101},{"cost":"KES 2.4000","messageId":"ATXid_3abf8670300ada1cbe63435c0c5ab60d","number":"+254725025536","status":"Success","statusCode":101}]}}}